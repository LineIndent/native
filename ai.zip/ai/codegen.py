"""
Converts a validated JSON tree (one that already rendered cleanly through
renderer.py, with zero errors) into actual Python source code — real
import statements plus a function returning the equivalent component call
chain. Verified via black: if black can't parse the output, that's a
genuine bug in codegen, not a style nit worth ignoring.
"""

import black

from registry import build_import_map
from chart_registry import build_chart_import_map


def _format_value(value):
    """Plain-literal repr for a prop value — this tool only ever generates
    static layouts, no Vars/state/event handlers to worry about."""
    return repr(value)


def _emit_node(node, import_modules: set, chart_names: set) -> str:
    if isinstance(node, str):
        return repr(node)

    if not isinstance(node, dict):
        raise ValueError(f"Cannot generate code for non-dict, non-string node: {node!r}")

    if "chart" in node:
        chart_name = node["chart"]
        chart_names.add(chart_name)
        return f"{chart_name}()"

    if "component" not in node:
        raise ValueError(f"Node has neither 'component' nor 'chart': {node!r}")

    component = node["component"]
    props = node.get("props", {}) or {}
    children = node.get("children", []) or []

    import_modules.add(component.split(".")[0])

    args = [_emit_node(c, import_modules, chart_names) for c in children]
    args += [f"{k}={_format_value(v)}" for k, v in props.items()]

    return f"{component}({', '.join(args)})"


def generate_code(tree: dict, function_name: str = "generated_component") -> str:
    import_map = build_import_map()
    chart_import_map = build_chart_import_map()

    import_modules: set = set()
    chart_names: set = set()

    body_expr = _emit_node(tree, import_modules, chart_names)

    lines = ["import reflex as rx", ""]

    for mod in sorted(import_modules):
        info = import_map.get(mod)
        if info:
            module_path, name = info
            lines.append(f"from {module_path} import {name}")
        else:
            # Shouldn't happen if the tree already passed renderer.py's
            # validation (which uses this same registry) — but don't
            # silently drop it if it does, surface it visibly instead.
            lines.append(f"# WARNING: no import found for '{mod}'")

    for chart_name in sorted(chart_names):
        module_path = chart_import_map.get(chart_name)
        if module_path:
            lines.append(f"from {module_path} import {chart_name}")
        else:
            lines.append(f"# WARNING: no import found for chart '{chart_name}'")

    source = "\n".join(lines) + "\n\n\n"
    source += f"def {function_name}() -> rx.Component:\n"
    source += f"    return {body_expr}\n"

    try:
        return black.format_str(source, mode=black.Mode())
    except Exception as e:
        # If black can't parse it, the generated code is likely invalid
        # Python — surface that loudly with the raw source, rather than
        # returning something that only looks plausible.
        raise ValueError(
            f"Generated code failed black formatting (likely invalid Python): {e}\n\n"
            f"--- raw generated source ---\n{source}"
        )


if __name__ == "__main__":
    import json
    import sys

    path = sys.argv[1] if len(sys.argv) > 1 else "sample_good.json"
    tree = json.load(open(path))
    print(generate_code(tree))
