import reflex as rx

from components.ui.accordion import accordion
from components.ui.card import card


def generated_component() -> rx.Component:
    return card.root(
        card.header(card.title("Accordion Features")),
        card.content(
            accordion.root(
                accordion.item(
                    accordion.trigger("Section 1"),
                    accordion.panel("Content for section 1 goes here."),
                    name="group-1",
                    class_name="border-b",
                ),
                accordion.item(
                    accordion.trigger("Section 2"),
                    accordion.panel("Content for section 2 goes here."),
                    name="group-1",
                    class_name="border-b",
                ),
                accordion.item(
                    accordion.trigger("Section 3"),
                    accordion.panel("Content for section 3 goes here."),
                    name="group-1",
                    class_name="border-b",
                ),
                class_name="w-full",
            )
        ),
    )
