import reflex as rx

from components.ui.frame import frame
from native.lib.charts.area.v1 import area_chart_basic_type


def generated_component() -> rx.Component:
    return frame.root(
        frame.panel(frame.header(frame.title("Dashboard")), class_name="w-64 border-r"),
        frame.panel(
            frame.header(frame.title("Analytics Overview")),
            area_chart_basic_type(),
            class_name="flex-1",
        ),
        variant="default",
        spacing="default",
        stacked=False,
    )
