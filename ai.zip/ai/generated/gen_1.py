import reflex as rx

from components.ui.button import button
from components.ui.card import card
from components.ui.field import field
from components.ui.input import input


def generated_component() -> rx.Component:
    return card.root(
        card.header(
            card.title("Login"),
            card.description("Enter your credentials to access your account."),
        ),
        card.content(
            field.set(
                field.group(
                    field.root(
                        field.label("Email", html_for="email"),
                        input(id="email", type="email"),
                        orientation="vertical",
                    ),
                    field.root(
                        field.label("Password", html_for="password"),
                        input(id="password", type="password"),
                        orientation="vertical",
                    ),
                )
            )
        ),
        card.footer(button("Sign in", variant="default")),
        size="default",
    )
